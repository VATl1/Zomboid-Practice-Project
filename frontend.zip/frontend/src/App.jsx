import { useEffect, useState } from "react";

const API = "http://localhost:8000";

function App() {
  const [items, setItems] = useState([]);
  const [stats, setStats] = useState({});
  const [filter, setFilter] = useState("");
  const [form, setForm] = useState({ Name: "", Type: "", Condition: "", Amount: "" });
  const [editId, setEditId] = useState(null);

  // Завантаження даних
  const loadData = async () => {
    const resItems = await fetch(`${API}/items`);
    const dataItems = await resItems.json();
    setItems(dataItems);

    const resStats = await fetch(`${API}/stats/all`);
    const dataStats = await resStats.json();
    setStats(dataStats);
  };

  useEffect(() => {
    loadData();
  }, []);

  // Додавання або редагування
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.Name || !form.Type || !form.Condition || !form.Amount) return;

    const method = editId ? "PUT" : "POST";
    const url = editId ? `${API}/items/${editId}` : `${API}/items`;

    await fetch(url, {
      method,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        Name: form.Name,
        Type: form.Type,
        Condition: form.Condition,
        Amount: parseInt(form.Amount),
      }),
    });

    setForm({ Name: "", Type: "", Condition: "", Amount: "" });
    setEditId(null);
    await loadData();
  };

  // Видалення
  const handleDelete = async (id) => {
    await fetch(`${API}/items/${id}`, { method: "DELETE" });
    await loadData();
  };

  // Почати редагування
  const startEdit = (item) => {
    setEditId(item.ID);
    setForm({
      Name: item.Name,
      Type: item.Type,
      Condition: item.Condition,
      Amount: item.Amount,
    });
  };

  const filteredItems = items.filter((i) =>
    i.Name.toLowerCase().includes(filter.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-zinc-950 text-gray-100 flex flex-col items-center p-8">
      <h1 className="text-4xl font-bold mb-6 text-emerald-400">
        🧟 Zomboid Accounting System
      </h1>

      {/* Поле пошуку */}
      <input
        type="text"
        placeholder="🔍 Пошук за назвою..."
        value={filter}
        onChange={(e) => setFilter(e.target.value)}
        className="mb-6 w-full max-w-md p-2 rounded bg-zinc-800 border border-zinc-700 focus:ring-2 focus:ring-emerald-400 outline-none"
      />

      {/* Таблиця */}
      <div className="w-full max-w-4xl overflow-x-auto">
        <table className="w-full border-collapse border border-zinc-700 text-sm">
          <thead className="bg-zinc-800 text-emerald-300">
            <tr>
              <th className="border border-zinc-700 px-3 py-2">ID</th>
              <th className="border border-zinc-700 px-3 py-2">Name</th>
              <th className="border border-zinc-700 px-3 py-2">Type</th>
              <th className="border border-zinc-700 px-3 py-2">Condition</th>
              <th className="border border-zinc-700 px-3 py-2">Amount</th>
              <th className="border border-zinc-700 px-3 py-2">Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredItems.map((item) => (
              <tr
                key={item.ID}
                className="hover:bg-zinc-800 transition-colors duration-150"
              >
                <td className="border border-zinc-700 px-3 py-2 text-center">{item.ID}</td>
                <td className="border border-zinc-700 px-3 py-2">{item.Name}</td>
                <td className="border border-zinc-700 px-3 py-2">{item.Type}</td>
                <td className="border border-zinc-700 px-3 py-2">{item.Condition}</td>
                <td className="border border-zinc-700 px-3 py-2 text-center">{item.Amount}</td>
                <td className="border border-zinc-700 px-3 py-2 text-center space-x-2">
                  <button
                    onClick={() => startEdit(item)}
                    className="px-2 py-1 bg-blue-600 rounded hover:bg-blue-500"
                  >
                    ✏️
                  </button>
                  <button
                    onClick={() => handleDelete(item.ID)}
                    className="px-2 py-1 bg-red-600 rounded hover:bg-red-500"
                  >
                    🗑️
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Статистика */}
      <div className="mt-10 w-full max-w-md bg-zinc-800 rounded-lg p-4 border border-zinc-700">
        <h2 className="text-xl font-semibold mb-3 text-emerald-300">
          📊 Статистика станів
        </h2>
        <ul className="space-y-1">
          {Object.entries(stats).map(([cond, perc]) => (
            <li key={cond} className="flex justify-between">
              <span>{cond}</span>
              <span className="text-emerald-400">{perc}%</span>
            </li>
          ))}
        </ul>
      </div>

      {/* Форма додавання / редагування */}
      <form
        onSubmit={handleSubmit}
        className="mt-10 flex flex-col gap-3 w-full max-w-3xl bg-zinc-800 p-4 rounded-lg border border-zinc-700"
      >
        <h2 className="text-xl font-semibold text-emerald-300">
          {editId ? "✏️ Редагувати предмет" : "➕ Додати новий предмет"}
        </h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <input
            type="text"
            placeholder="Name"
            value={form.Name}
            onChange={(e) => setForm({ ...form, Name: e.target.value })}
            className="p-2 rounded bg-zinc-900 border border-zinc-700"
          />
          <input
            type="text"
            placeholder="Type"
            value={form.Type}
            onChange={(e) => setForm({ ...form, Type: e.target.value })}
            className="p-2 rounded bg-zinc-900 border border-zinc-700"
          />
          <input
            type="text"
            placeholder="Condition"
            value={form.Condition}
            onChange={(e) => setForm({ ...form, Condition: e.target.value })}
            className="p-2 rounded bg-zinc-900 border border-zinc-700"
          />
          <input
            type="number"
            placeholder="Amount"
            value={form.Amount}
            onChange={(e) => setForm({ ...form, Amount: e.target.value })}
            className="p-2 rounded bg-zinc-900 border border-zinc-700"
          />
        </div>
        <button
          type="submit"
          className="mt-3 bg-emerald-600 hover:bg-emerald-500 text-white py-2 rounded"
        >
          {editId ? " Зберегти зміни" : " Додати"}
        </button>
      </form>
    </div>
  );
}

export default App;